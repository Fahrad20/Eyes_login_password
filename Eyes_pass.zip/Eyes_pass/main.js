let eye1 = document.querySelector('.a1');
let eye2 = document.querySelector('.b1');

function arcctg(x, y) {
    if (x > 0 && y > 0) {
        return Math.PI / 2 - Math.atan(x / y);
    } else if (x < 0 && y > 0) {
        return Math.PI / 2 - Math.atan(x / y);
    } else if (x < 0 && y < 0) {
        return Math.PI + Math.atan(y / x);
    } else {
        return 3 * Math.PI / 2 + Math.abs(Math.atan(x / y));
    }
}
let x = 0;
pass.onfocus = () => {
    x = 0;
    setInterval(function () {
        eye1.style = `transform: translate(-80%,150%) rotate(${115 - (pass.value.length * 1.5)}deg)`;
        eye2.style = `transform: translate(-80%,150%) rotate(${115 - (pass.value.length * 1.5)}deg)`;
    }, 1);
}
pass2.onfocus = () => {
    hand.style.left = '0';
    document.onclick = () => {
        x++;
        if (x > 1) {
            hand.style.left = '-200px';
            x = 0;
        }
    }
}
